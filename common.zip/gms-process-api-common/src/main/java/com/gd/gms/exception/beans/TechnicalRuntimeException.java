package com.gd.gms.exception.beans;

public class TechnicalRuntimeException extends RuntimeException {

    public TechnicalRuntimeException() {
    }

    public TechnicalRuntimeException(String message) {
        super(message);
    }

    public TechnicalRuntimeException(String message, Throwable cause) {
        super(message, cause);
    }

    public TechnicalRuntimeException(Throwable cause) {
        super(cause);
    }

}
