package com.gd.gms.exception.beans;

import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

public class BusinessException extends Exception {

    private List<ErrorInfo> errorInfo;

    private HttpStatus httpStatus;

    public List<ErrorInfo> getErrorInfo() {
        if (null == this.errorInfo) {
            this.errorInfo = new ArrayList<>();
        }
        return errorInfo;
    }

    public void setErrorInfo(List<ErrorInfo> errorInfo) {
        this.errorInfo = errorInfo;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }
}
