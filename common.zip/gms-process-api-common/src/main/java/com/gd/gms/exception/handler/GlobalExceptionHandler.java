package com.gd.gms.exception.handler;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.gd.gms.exception.Constants.ErrorConstants;
import com.gd.gms.exception.beans.BusinessException;
import com.gd.gms.exception.beans.ErrorInfo;
import com.gd.gms.exception.beans.ErrorResponse;
import com.gd.gms.exception.beans.TechnicalException;
import com.gd.gms.exception.util.ErrorResponseBuilderUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.context.request.WebRequest;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class.getName());
    @Autowired
    MessageSource messageSource;

    @ExceptionHandler(value = BusinessException.class)
    public ResponseEntity<Object> handleBusinessException(final BusinessException exception, final WebRequest request) {
        GlobalExceptionHandler.LOGGER.error("Logging BusinessException ", exception);
        List<ErrorInfo> errorInfoList = exception.getErrorInfo();
        ErrorResponse errorResponse = ErrorResponseBuilderUtil.createErrorResponseForExceptions(errorInfoList, exception.getMessage(), null);
        errorResponse = ErrorResponseBuilderUtil.populateCorrelationIds(errorResponse, request);
        return new ResponseEntity<>(errorResponse, null != exception.getHttpStatus() ? exception.getHttpStatus() : HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = TechnicalException.class)
    public ResponseEntity<Object> handleTechnicalException(final TechnicalException exception, final WebRequest request) {
        GlobalExceptionHandler.LOGGER.error("Logging TechnicalException ", exception);
        ErrorResponse errorResponse;
        if (StringUtils.isNotEmpty(exception.getMessage())) {
            errorResponse = ErrorResponseBuilderUtil.createErrorResponseForExceptions(null, exception.getMessage(), ErrorConstants.TECH_ERROR_CODE);
        } else {
            errorResponse = ErrorResponseBuilderUtil.createErrorResponseForExceptions(null, ErrorConstants.TECH_ERROR_MSG, ErrorConstants.TECH_ERROR_CODE);
        }
        errorResponse = ErrorResponseBuilderUtil.populateCorrelationIds(errorResponse, request);
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        return responseEntity;
    }

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<Object> handleException(final Exception exception, final WebRequest request) {
        GlobalExceptionHandler.LOGGER.error("Logging Exception ", exception);
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
        ErrorResponse
                errorResponse = ErrorResponseBuilderUtil.createErrorResponseForExceptions(null, exception.getMessage(), ErrorConstants.TECH_ERROR_CODE);
        errorResponse = ErrorResponseBuilderUtil.populateCorrelationIds(errorResponse, request);
        if (exception instanceof HttpServerErrorException) {
            status = ((HttpServerErrorException) exception).getStatusCode();
        }
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(errorResponse, status);
        return responseEntity;
    }

    @ExceptionHandler(value = HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<Object> handleHttpMethodNotSupportedException(final HttpRequestMethodNotSupportedException exception, final WebRequest request) {
        GlobalExceptionHandler.LOGGER.error("Logging HttpRequestMethodNotSupportedException ", exception);
        ErrorResponse errorResponse = ErrorResponseBuilderUtil.createErrorResponseForExceptions(null, exception.getMessage(), HttpStatus.METHOD_NOT_ALLOWED.toString());
        errorResponse = ErrorResponseBuilderUtil.populateCorrelationIds(errorResponse, request);
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(errorResponse, HttpStatus.METHOD_NOT_ALLOWED);
        return responseEntity;
    }

    @ExceptionHandler(value = HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<Object> handleHttpMediaTypeNotSupportedException(final HttpMediaTypeNotSupportedException exception, final WebRequest request) {
        GlobalExceptionHandler.LOGGER.error("Logging HttpMediaTypeNotSupportedException ", exception);
        ErrorResponse errorResponse = ErrorResponseBuilderUtil.createErrorResponseForExceptions(null, exception.getMessage(), HttpStatus.UNSUPPORTED_MEDIA_TYPE.toString());
        errorResponse = ErrorResponseBuilderUtil.populateCorrelationIds(errorResponse, request);
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(errorResponse, HttpStatus.UNSUPPORTED_MEDIA_TYPE);
        return responseEntity;
    }

    @ExceptionHandler(value = HttpMessageNotReadableException.class)
    public ResponseEntity<ErrorResponse> handleHttpMediaTypeNotSupportedException(final HttpMessageNotReadableException exception, final WebRequest request) {
        GlobalExceptionHandler.LOGGER.error("Logging HttpMessageNotReadableException ", exception);
        String cause = "HTTP message not Readable";
        String field = "HttpMessage";
        Throwable throwable = exception.getCause();
        if (throwable instanceof JsonMappingException) {
            field = getJsonMappingErrorField((JsonMappingException) throwable);
            cause = "Cannot parse field";
        }
        List<ErrorInfo> errorInfoList = Collections.singletonList(ErrorResponseBuilderUtil.createErrorInfo(cause, "", field));
        ErrorResponse errorResponse = ErrorResponseBuilderUtil.createErrorResponseForExceptions(errorInfoList, "400", cause);
        errorResponse = ErrorResponseBuilderUtil.populateCorrelationIds(errorResponse, request);
        ResponseEntity<ErrorResponse> responseEntity = new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        return responseEntity;
    }

    @ExceptionHandler(value = HttpMessageNotWritableException.class)
    public ResponseEntity<ErrorResponse> handleHttpMessageNotWritableException(final HttpMessageNotWritableException exception, final WebRequest request) {
        GlobalExceptionHandler.LOGGER.error("Logging HttpMessageNotWritableException ", exception);
        String cause = "HTTP message not writable";
        String field = "HttpMessage";
        Throwable throwable = exception.getCause();
        if (throwable instanceof JsonMappingException) {
            field = getJsonMappingErrorField((JsonMappingException) throwable);
            cause = "Cannot write field";
        }
        List<ErrorInfo> errorInfoList = Collections.singletonList(ErrorResponseBuilderUtil.createErrorInfo(cause, ErrorConstants.GENERAL_BUSINESS_ERROR, field));
        ErrorResponse errorResponse = ErrorResponseBuilderUtil.createErrorResponseForExceptions(errorInfoList, ErrorConstants.GENERAL_BUSINESS_ERROR, cause);
        errorResponse = ErrorResponseBuilderUtil.populateCorrelationIds(errorResponse, request);
        ResponseEntity<ErrorResponse> responseEntity = new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        return responseEntity;
    }

    @ExceptionHandler(value = ConstraintViolationException.class)
    public ResponseEntity<ErrorResponse> handleConstraintViolationException(final ConstraintViolationException exception, final WebRequest request) {
        GlobalExceptionHandler.LOGGER.error("Logging ConstraintViolationException ", exception);
        Set<ConstraintViolation<?>> constraintViolations = exception.getConstraintViolations();
        List<ErrorInfo> errorInfoList = constraintViolations.stream().map(constraintViolation ->
                ErrorResponseBuilderUtil.createErrorInfo(constraintViolation.getInvalidValue().toString(), constraintViolation.getMessage(), ErrorConstants.GENERAL_BUSINESS_ERROR)).collect(Collectors.toList());
        ErrorResponse errorResponse = ErrorResponseBuilderUtil.createErrorResponseForExceptions(errorInfoList, ErrorConstants.GENERAL_BUSINESS_ERROR, "PathParams Validation Exception");
        errorResponse = ErrorResponseBuilderUtil.populateCorrelationIds(errorResponse, request);
        ResponseEntity<ErrorResponse> responseEntity = new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        return responseEntity;
    }

    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public ResponseEntity<Object> handleMethodArgumentNotValidException(final MethodArgumentNotValidException exception, final WebRequest request) {
        GlobalExceptionHandler.LOGGER.error("Logging MethodArgumentNotValidException ", exception);
        BindingResult br = exception.getBindingResult();
        List<ObjectError> errors = br.getAllErrors();
        List<ErrorInfo> errorInfoList = new ArrayList<>();
        for (ObjectError error : errors) {
            ErrorInfo errorInfo = null;
            if (error instanceof FieldError) {
                FieldError fe = (FieldError) error;
                String errorMessage;
                if (StringUtils.contains(error.getDefaultMessage(), '{')) {
                    errorMessage = this.messageSource.getMessage(error.getDefaultMessage().replace("{", "").replace("}", ""), null, null);
                    errorInfo = ErrorResponseBuilderUtil.createErrorInfo(errorMessage.substring(5), errorMessage.substring(0, 4), fe.getField());
                } else if (StringUtils.isNotBlank(error.getDefaultMessage())) {
                    errorInfo = ErrorResponseBuilderUtil.createErrorInfo(fe.getDefaultMessage(), ErrorConstants.SCHEMA_ERROR_CODE, fe.getField());
                } else {
                    errorMessage = this.messageSource.getMessage(error.getCode(), null, null);
                    String code = errorMessage.substring(0, 4);
                    if (StringUtils.isNotBlank(code) && StringUtils.equalsIgnoreCase(code, ErrorConstants.TECH_ERROR_CODE)) {
                        TechnicalException technicalException = new TechnicalException(errorMessage.substring(5));
                        return handleTechnicalException(technicalException, request);
                    }
                    errorInfo = ErrorResponseBuilderUtil.createErrorInfo(errorMessage.substring(5), errorMessage.substring(0, 4), fe.getField());
                }
            }
            errorInfoList.add(errorInfo);
        }
        BusinessException businessException = new BusinessException();
        businessException.getErrorInfo().addAll(errorInfoList);
        return handleBusinessException(businessException, request);
    }

    private String getJsonMappingErrorField(JsonMappingException throwable) {
        List<JsonMappingException.Reference> references = throwable.getPath();
        if (!references.isEmpty()) {
            JsonMappingException.Reference reference = references.get(references.size() - 1);
            return reference.getFieldName();
        }
        return "";
    }
}

