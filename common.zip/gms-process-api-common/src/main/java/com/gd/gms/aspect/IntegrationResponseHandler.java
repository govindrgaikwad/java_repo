package com.gd.gms.aspect;

public class IntegrationResponseHandler {
}
