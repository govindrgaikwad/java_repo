package com.gd.gms.exception.beans;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ErrorResponse implements Serializable {

    private List<ErrorInfo> errorInfo;

    private String requestCorrelation;

    private String sessionCorrelation;

    public List<ErrorInfo> getErrorInfo() {
        return errorInfo;
    }

    public void setErrorInfo(List<ErrorInfo> errorInfo) {
        if (null == this.errorInfo) {
            this.errorInfo = new ArrayList<>();
        }
        this.errorInfo = errorInfo;
    }

    public String getRequestCorrelation() {
        return requestCorrelation;
    }

    public void setRequestCorrelation(String requestCorrelation) {
        this.requestCorrelation = requestCorrelation;
    }

    public String getSessionCorrelation() {
        return sessionCorrelation;
    }

    public void setSessionCorrelation(String sessionCorrelation) {
        this.sessionCorrelation = sessionCorrelation;
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj);
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}
