package com.gd.gms.exception.Constants;

public class ErrorConstants {

    public static final String TECH_ERROR_CODE = "9999";

    public static final String TECH_ERROR_MSG = "Technical Error";

    public static final String SCHEMA_ERROR_CODE = "0020";

    public static final String GENERAL_BUSINESS_ERROR = "400";
}
