package com.gd.gms.exception.util;

import com.gd.gms.exception.beans.ErrorDetail;
import com.gd.gms.exception.beans.ErrorInfo;
import com.gd.gms.exception.beans.ErrorResponse;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.context.request.WebRequest;

import java.util.List;

public final class ErrorResponseBuilderUtil {

    public static ErrorResponse createErrorResponseForExceptions(final List<ErrorInfo> errorInfoList, final String cause, final String code) {
        ErrorResponse errorResponse = new ErrorResponse();
        //BusinessException
        if(null != errorInfoList && !errorInfoList.isEmpty()){
            errorResponse.getErrorInfo().addAll(errorInfoList);
        }else {
            //Technical Exception or any other Exception
            ErrorInfo errorInfo = createErrorInfo(cause, code, null);
            errorResponse.getErrorInfo().add(errorInfo);
        }
        return errorResponse;
    }

    public static ErrorInfo createErrorInfo(final String cause, final String code, final String field){
        ErrorInfo errorInfo = new ErrorInfo();
        ErrorDetail detail= new ErrorDetail();
        if (StringUtils.isNotBlank(cause)){
            detail.setCause(cause);
        }

        if (StringUtils.isNotBlank(field)){
            detail.setField(field);
        }

        if (StringUtils.isNotBlank(code)){
            errorInfo.setCode(code);
        }
        errorInfo.setDetail(detail);
        return errorInfo;
    }

    public static ErrorResponse populateCorrelationIds(final ErrorResponse errorResponse, final WebRequest  request){
        errorResponse.setRequestCorrelation(request.getHeader(""));
        errorResponse.setSessionCorrelation(request.getHeader(""));
        return  errorResponse;
    }
}
