package com.gd.gms.exception.beans;

public class TechnicalException extends Exception {

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public TechnicalException(String message) {
        super(message);
        this.message = message;
    }

    public TechnicalException(String message, Throwable cause) {
        super(message, cause);
        this.message = message;
    }

    public TechnicalException(Exception exception) {
        super(exception.getMessage());
        this.message = exception.getMessage();
    }
}
